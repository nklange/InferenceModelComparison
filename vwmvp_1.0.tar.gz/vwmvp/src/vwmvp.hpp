#include <Rcpp.h>
using namespace Rcpp;

double cKappaFromJ(double J);
